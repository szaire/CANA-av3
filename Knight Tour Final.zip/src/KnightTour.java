// Java program for Knight Tour problem
class KnightTour {
    // inicializando as variáveis da solução do problema
    private final int[][] solution = new int[8][8];
    private final int board_side_size = 8;
    int[] xMove;
    int[] yMove;

    // inicializando o tabuleiro e variáveis de movimento
    {
        for (int x = 0; x < board_side_size; x++) {
            for (int y = 0; y < board_side_size; y++) {
                solution[x][y] = -1;
            }
        }

        this.solution[0][0] = 0;
        this.xMove = new int[]{2, 1, -1, -2, -2, -1, 1, 2};
        this.yMove = new int[]{1, 2, 2, 1, -1, -2, -2, -1};
    }

    // Resolução do problema do cavalo (knight tour)
    /**
     * Inicialização padrão do algoritmo de resolução do problema do cavalo.
     * */
    public void knightTour() {
        if (!solve(0, 0, 1, this.solution, this.xMove, this.yMove)) {
            System.out.println("Não existe solução para os dados de entrada fornecidos.");
        } else {
            printSolution(solution);
        }
    }

    /**
     * @param x Posição inicial do cavalo no eixo X.
     * @param y Posição inicial do cavalo no eixo Y.
     * */
    public void knightTour(int x, int y) {
        if (!solve(x, y, 1, this.solution, this.xMove, this.yMove)) {
            System.out.println("Não existe solução para os dados de entrada fornecidos.");
        } else {
            printSolution(solution);
        }
    }

    // método que checa se a posição alvo está contida dentro do tabuleiro e se não foi visitada
    private boolean isSafe(int x, int y, int[][] solution)
    {
        return (x >= 0 && x < board_side_size &&
                y >= 0 && y < board_side_size &&
                solution[x][y] == -1);
    }
//    private boolean isSafe(int x, int y, int sol[][]) throws Exception
//    {
//        if (x >= 0 && x < board_side_size && y >= 0 && y < board_side_size && sol[x][y] == -1) {
//            return true;
//        }
//        else {
//            throw new Exception();
//        }
//    }

    // o print da solução no console ao terminar o knight tour
    private void printSolution(int[][] solution) {
        for (int x = 0; x < board_side_size; x++) {
            for (int y = 0; y < board_side_size; y++) {
                if (solution[x][y] < 10) {
                    System.out.print("[0" + solution[x][y] + "] ");
                }
                else {
                    System.out.print("[" + solution[x][y] + "] ");
                }
            }
            System.out.println();
        }
    }

    // A função recursiva que resolve o problema do cavalo
    private boolean solve(int x, int y, int movement, int[][] solution, int[] xMove, int[] yMove) {
        int k, next_x, next_y;
        if (movement == board_side_size * board_side_size)
            return true;

        // Tenta todos os movimentos, sempre que possível, para a posição atual
//        printBoardIteraction(solution);
        for (k = 0; k < 8; k++) {
            next_x = x + xMove[k];
            next_y = y + yMove[k];

            if (isSafe(next_x, next_y, solution)) {
                solution[next_x][next_y] = movement;

                if (solve(next_x, next_y, movement + 1, solution, xMove, yMove)) {
                    return true;
                } else {
                    solution[next_x][next_y] = -1; // backtracking
                }
            }
        }
        return false;
    }

    private void printBoardIteraction(int[][] board) {
        for (int x = 0; x < board.length; x++) {
            for (int y = 0; y < board[0].length; y++) {
                if (board[x][y] < 0) {
                    System.out.print(" ██ ");
                }
                else if (board[x][y] < 10) {
                    System.out.print(" 0" + board[x][y] + " ");
                }
                else {
                    System.out.print(" " + board[x][y] + " ");
                }
            }
            System.out.println();
        }
        System.out.println("===============================");
    }
}
