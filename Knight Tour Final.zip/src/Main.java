public class Main {
    public static void main(String[] args) {
        KnightTour kt = new KnightTour();
        kt.knightTour();
    }
}
